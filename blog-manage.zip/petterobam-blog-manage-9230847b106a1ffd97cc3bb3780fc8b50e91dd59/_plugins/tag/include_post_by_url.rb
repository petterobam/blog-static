module Jekyll
  class IncludePostByUrlTag < Liquid::Tag
    def initialize(tag_name, url, tokens)
      super
      @url = url.strip
    end

    def render(context)
      site = context.registers[:site]
      document_to_include = nil
    
      # Use the pre-generated site.all_documents variable
      all_documents = site.config['all_documents']
    
      all_documents.each do |document|
        if document.url == @url
          document_to_include = document
          break
        end
      end
    
      if document_to_include
        document_to_include.content
      else
        if site.config['lang'] == 'zh'
          "文档不存在"
        else
          "Document not found"
        end
      end
    end      
  end
end

Liquid::Template.register_tag('include_post_by_url', Jekyll::IncludePostByUrlTag)
