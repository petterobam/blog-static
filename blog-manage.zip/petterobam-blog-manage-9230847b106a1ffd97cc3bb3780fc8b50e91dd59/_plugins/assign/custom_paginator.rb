module Jekyll
  class CustomPaginator < Generator
    safe true
    priority :lowest

    def generate(site)
      all_documents = site.config['all_documents'] # 所有的帖子
      all_documents = all_documents.select { |doc| doc['action'] != 'hide' }
      all_documents = remove_duplicates(all_documents, 'title') # 去重
      all_documents = all_documents.sort_by { |doc| doc['date'] }.reverse

      per_page = site.config['paginate'] || 5
      paginate_path = site.config['paginate_path'] || '/page:num'
      pages = (all_documents.size.to_f / per_page).ceil

      (1..pages).each do |num|
        page_data = {
          'page' => num,
          'per_page' => per_page,
          'posts' => all_documents.slice((num - 1) * per_page, per_page),
          'total_posts' => all_documents.size,
          'total_pages' => pages,
          'next_page' => (num == pages) ? nil : num + 1,
          'next_page_path' => (num == pages) ? nil : paginate_path.sub(':num', (num + 1).to_s),
          'previous_page' => (num == 1) ? nil : num - 1,
          'previous_page_path' => (num == 1) ? nil : paginate_path.sub(':num', (num - 1).to_s)
        }

        if num == 1
          site.config['paginator'] = page_data # 设置全局的 paginator 对象，用于首页渲染
        end

        site.pages << CustomPage.new(site, all_documents, num, per_page, paginate_path, page_data)
      end
    end

    def remove_duplicates(posts, field)
      # 创建一个空的哈希表来跟踪已经见过的标题
      seen_values = {}
      unique_posts = []

      # 遍历文章并按标题进行去重
      posts.each do |post|
        value = post[field]

        unless seen_values.key?(value)
          seen_values[value] = true
          unique_posts << post
        end
      end
      unique_posts
    end
  end

  class CustomPage < Page
    def initialize(site, _all_documents, num, _per_page, paginate_path, page_data)
      @site = site
      @base = site.source
      @dir  = paginate_path.sub(':num', num.to_s)
      @name = 'index.html'

      process(@name)
      read_yaml(File.join(@base, '_layouts'), 'home.html')
      data['title'] = "Page #{num}"
      data['paginator'] = page_data
    end
  end
end
