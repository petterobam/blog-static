module Jekyll
    module ArrayMergeFilter
        def merge_arrays(input1, input2)
            input1.concat(input2)
        end
    end
end
  
Liquid::Template.register_filter(Jekyll::ArrayMergeFilter)
  
  